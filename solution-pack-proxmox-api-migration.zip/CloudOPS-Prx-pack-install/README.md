CloudOPS Proxmox Pack
======================

This FortiSOAR solution pack provides playbooks and data models to request, provision, and destroy Proxmox VE VMs and containers, plus an inventory sync.

Requirements
------------
- FortiSOAR 7.2.0 or later
- Proxmox VE with API access and a token
- Proxmox API connector (`proxmox-api`) installed from `API Connector Proxmox.tgz`

Contents
--------
- Modules and views for VM instances and network interfaces
- Playbooks for requesting, provisioning, destroying, and refreshing Proxmox inventory
- Global variables for Proxmox connection and templates

Installation
------------
1. Import the connector package `API Connector Proxmox.tgz` in FortiSOAR.
2. Import this solution pack `solution-pack-proxmox-api-migration.tgz`.
3. Update the Proxmox-related global variables (host, port, token, node, storage, templates).
4. Configure the `proxmox-api` connector with the correct host, port, and token.

Usage
-----
- Use the service management playbooks to request and provision VMs/containers.
- Use the destroy playbooks to remove instances.
- Use the "> Refresh Proxmox Inventory" playbook to sync Proxmox VMs/CTs with the `v_m_instances` module.
