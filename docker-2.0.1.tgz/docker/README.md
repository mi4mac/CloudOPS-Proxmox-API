# Docker Connector

FortiSOAR connector for the Docker Engine API.

## Included
- Connector code (`connector.py`, `builtins.py`, and modules)
- Configuration metadata (`info.json`)
- Sample playbooks (`playbooks/playbooks.json`)

## Notes
- The sample playbook collection is removed on connector upgrade or deletion. Clone it before use.
