# Proxmox API Samples

Diese Playbook-Sammlung wird mit dem Connector **API Connector Proxmox** mitgeliefert. Jede Connector-Operation hat ein Sample-Playbook.

## Playbooks (alle Operationen)

| Playbook | Operation | Beschreibung |
|----------|-----------|--------------|
| **Test Proxmox Connection** | get_version | Proxmox-Version abfragen, Verbindung prüfen. |
| **Get Next VMID** | get_next_vmid | Nächste verfügbare VMID ermitteln. |
| **Clone VM (Sample)** | clone_vm | VM von Template klonen. |
| **Create Container (Sample)** | create_container | LXC-Container anlegen. |
| **Configure VM (Sample)** | config_vm | VM konfigurieren (z. B. Cloud-Init, Netzwerk). |
| **Start VM (Sample)** | start_vm | VM starten. |
| **Start Container (Sample)** | start_container | LXC-Container starten. |
| **Stop Container (Sample)** | stop_container | LXC-Container stoppen. |
| **Destroy VM (Sample)** | stop_vm + destroy_vm | VM stoppen und löschen. |
| **Destroy Container (Sample)** | stop_container + destroy_container | Container stoppen und löschen. |
| **API Request Generic (Sample)** | api_request | Beliebige API-Anfrage (GET/POST/PUT/DELETE). |

## Verwendung

1. Connector **API Connector Proxmox** (proxmox-api) importieren und eine Konfiguration anlegen (Host, Port, API Token).
2. Beim Ausführen eines Sample-Playbooks die **Connector-Konfiguration** auswählen.
3. In den Sample-Steps die Parameter (node, vmid, name, url_path, …) an Ihre Umgebung anpassen oder per Variable übergeben.
